#!/bin/bash
exit 0
log_file=/tmp/vpn_login_tmp.log
if [ -z "$username" ];then
	exit 1
fi
mysql -e"use labsystem;select * from vpnuser where vpnuser.username='${username}' and vpnuser.status=1;" > $log_file
passwd=`awk '{if(NR==2){print $9}}' $log_file`
password=`echo -n ${password}labsystem_salt | md5sum | awk '{print $1}'`
if [ "$passwd" == "$password" ];then
	exit 0
fi
exit 1
