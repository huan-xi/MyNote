#!/bin/bash
log_file=/tmp/vpn_login_tmp.log
mysql -e"use labsystem;select * from vpnuser where vpnuser.username='${username}' and vpnuser.status=1;" > $log_file
send=`awk '{if(NR==2){print $3}}' $log_file`
recv=`awk '{if(NR==2){print $4}}' $log_file`
echo $send >> ~/test.log
send=$[$send+$bytes_sent]
recv=$[$recv+$bytes_received]
mysql -e"use labsystem;update vpnuser set recv='$recv'  where username='${username}';" 
mysql -e"use labsystem;update vpnuser set send='$send'  where username='${username}';"
echo username:${username} 本次发送：${bytes_sent}，本次接受：${bytes_received} 时间：$(date)>> /tmp/connect.log
