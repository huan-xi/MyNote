echo `awk -F , '$1~10.8' /etc/openvpn/openvpn-status.log  | wc -l`

