echo kill $1 | telnet localhost 7505
