#!/bin/bash
# openVPN启动脚本
nohup openvpn /etc/openvpn/server.conf >>/dev/null &
#开启iptables转发
sh /etc/openvpn/firewall.sh
