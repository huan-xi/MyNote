iptables -t nat -A POSTROUTING -s 10.8.0.0/24 -o eth0 -j MASQUERADE
iptables -A INPUT -i lo -p all -j ACCEPT
iptables -A INPUT -p all -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A INPUT -i tun+ -j ACCEPT
iptables -A FORWARD -i tun+ -j ACCEPT
#iptables -A INPUT -p tcp -m tcp --dport 465 -j ACCEPT
#iptables -A INPUT -p tcp -m tcp --dport 110 -j ACCEPT
#iptables -A INPUT -p tcp -m tcp --dport 25 -j ACCEPT
#iptables -A INPUT -p tcp -m tcp --dport 22 -j ACCEPT
iptables -A INPUT -p udp --dport 1194 -j ACCEPT
iptables -A INPUT -s 10.8.0.0/24 -p all -j ACCEPT
iptables -A FORWARD -d 10.8.0.0/24 -j ACCEPT
iptables -A INPUT -p tcp -m tcp --dport 22 -j ACCEPT
