#!/bin/bash
echo 用户名：${username} 密码：${password} log test >> /tmp/login_log.log
exit 0
