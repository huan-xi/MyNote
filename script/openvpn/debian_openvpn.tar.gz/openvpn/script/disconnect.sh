#!/bin/bash
echo username:${username} 本次发送：${bytes_sent}，本次接受：${bytes_received} 时间：$(date)>> /tmp/connect.log
